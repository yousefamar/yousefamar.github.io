using UnityEngine;
using System.Collections;

public class Creature : MonoBehaviour {
	
	private int soundTimer;
	private HUD hud;
	
	void Start() {
		hud = GameObject.FindWithTag("HUD").GetComponent<HUD>();
	}
	
	void FixedUpdate () {
		/* If the creature has a sound, play it at random intervals with a random pitch. */
		if (audio && --soundTimer<=0) {
			if (soundTimer==0) {
				audio.pitch = Random.Range(0.5F, 1.5F);
				audio.Play();
			}
			soundTimer = Random.Range(100, 500);
		}
	}
	
	void OnTriggerEnter(Collider other) {
		/* When the player enters the trigger bounding cube, increment their score and delete the creature. */
		Destroy(this.gameObject);
		hud.IncScore();
		GameObject.FindWithTag("MainCamera").audio.Play();
		Debug.Log("A creature has been saved!");
    }
}
