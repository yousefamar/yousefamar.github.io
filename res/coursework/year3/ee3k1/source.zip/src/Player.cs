using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	
	private float wave;
	private bool onBoat;
	
	void FixedUpdate () {
		/* Move with the waves if on water or the boat. */
		if (wave > 359)
			wave = 0;
		if (onBoat) {
			if (transform.position.y < 4.5F)
				transform.Translate(0, (3.7F - transform.position.y)+Mathf.Sin((wave+=2.0F)*Mathf.Deg2Rad)/2.0F, 0);
			else
				transform.Translate(0, -0.1F, 0);
		} else if (!onBoat && transform.position.y < 2.5F)
			transform.Translate(0, (2.0F - transform.position.y)+Mathf.Sin((wave+=2.0F)*Mathf.Deg2Rad)/2.0F, 0);
	}
	
	public void SetOnBoat(bool onBoat) {
		Debug.Log("Player has "+(onBoat?"entered":"left")+" the boat.");
		this.onBoat = onBoat;
	}
}
