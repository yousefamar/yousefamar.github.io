using UnityEngine;
using System.Collections;

public class Boat : MonoBehaviour {
	
	private GameObject player;
	private Player playerScript;
	private CharacterMotorMovement playerMovement;
	private bool isTouching;
	private bool isMounted;
	private float wave;
	
	void Start() {
		player = GameObject.FindWithTag("Player");
		playerScript = player.GetComponent<Player>();
		playerMovement = player.GetComponent<CharacterMotor>().movement;
		//prevPlayerPos = new Vector2(player.transform.position.x, player.transform.position.z);
	}
	
	void Update() {
		if (Input.GetKeyDown(KeyCode.E) && isTouching) {
			isMounted = !isMounted;
			/* When the player mounts/dismounts the boat, lock/unlock it relative to the player. */
			transform.parent = isMounted?player.transform:null;
			transform.position.Set(0,-10,0);
			playerScript.SetOnBoat(isMounted);
			if (isMounted)
				audio.Play();				
		}
		if (isMounted) {
			/* Gradually fade in the boat motor sound. */
			if (audio.volume < 0.5F)
				audio.volume += 0.05F;
		} else {
			/* Gradually fade out the boat motor sound. */
			if (audio.volume > 0.0F) {
				audio.volume -= 0.05F;
				if (audio.volume <= 0.0F)
					audio.Stop();
			}
		}
		/* Set the motor sound pitch depending on boat speed. */
		if (audio.isPlaying)
			audio.pitch = (playerMovement.velocity.magnitude/30.0F)+1.0F;
	}
	
	void OnGUI() {
		if (isTouching && !isMounted)
			GUI.Box(new Rect((Screen.width-210)/2, (Screen.height-24)*2/3, 210, 24), "Press \"E\" to start/stop the boat.");
	}
	
	void FixedUpdate () {
		/* Move with the waves if on water. */
		if (wave > 359)
			wave = 0;
		if (!isMounted) {
			if (transform.position.y <= 2.0F)
				transform.Translate(0, (1.5F - transform.position.y)+Mathf.Sin((wave+=2.0F)*Mathf.Deg2Rad)/4.0F, 0);
			else
				transform.Translate(0, -0.1F, 0);	
		}
	}
	
	void OnTriggerEnter(Collider other) {
		if (other.Equals(player.collider))
			isTouching = true;
    }
	
	void OnTriggerExit(Collider other) {
		if (other.Equals(player.collider))
			isTouching = false;
	}
	
    void OnTriggerStay(Collider other) {
		/*Debug.Log(player.transform.position.ToString()+" "+transform.position.ToString());
		transform.Translate(prevPlayerPos.x, 0 ,prevPlayerPos.z);
		prevPlayerPos.Set(player.transform.position.x, player.transform.position.y, player.transform.position.z);*/
    }
}