using UnityEngine;
using System.Collections;

public class HUD : MonoBehaviour {
	
	public Texture2D timeup;
	
	private int timer = 120;
	private int score = 0;
	private bool isTimeUp;
	
	private CharacterMotor playerController;
	private MouseLook playerMouseLook;
	private MouseLook cameraMouseLook;
	private BlurEffect cameraBlur;
	private AudioSource boatAudio;
	
	void Start() {
		GameObject player = GameObject.FindWithTag("Player");
		GameObject camera = GameObject.FindWithTag("MainCamera");
		playerController = player.GetComponent<CharacterMotor>();
		playerMouseLook = player.GetComponent<MouseLook>();
		cameraMouseLook = camera.GetComponent<MouseLook>();
		cameraBlur = camera.GetComponent<BlurEffect>();
		boatAudio = GameObject.FindWithTag("Boat").audio;
		/* If in time trial mode, create a timer thread that starts in 1s and decrements the timer every subsequent 1s. */
		if (GameData.timeTrial)
			InvokeRepeating("DecTimer", 1.0F, 1.0F);
		Screen.showCursor = false;
	}
	
	void Update() {
		/* Return to main menu if player presses Esc. */
		if (Input.GetKeyDown(KeyCode.Escape)) {
			Application.LoadLevel(0);
			Screen.showCursor = true;
		}
	}
	
	void OnGUI() {
		/* Draw HUD and, if time is up, "Time Up!" screen. */
		GUI.Label(new Rect(0, 0, 200, 20), " Saved Creatures: "+score);
		GUI.Label(new Rect(0, 20, 200, 20), " Time Left: "+(GameData.timeTrial?timer.ToString():"\u221e")+"s");
		if (isTimeUp) {
			GUI.DrawTexture(new Rect((Screen.width-500)/2, (Screen.height-125)/2, 500, 125), timeup);
			if (GUI.Button(new Rect((Screen.width-100)/2-100, ((Screen.height-20)/2)+100, 100, 30), "Retry"))
				Application.LoadLevel(Application.loadedLevel);
			if (GUI.Button(new Rect(((Screen.width-100)/2)+100, ((Screen.height-20)/2)+100, 100, 30), "Main Menu"))
				Application.LoadLevel(0);
		}
	}
	
	private void DecTimer() {
		if (--timer < 6) {
			/* When there are only 5 seconds left, play a beep at every decrement and a low pitch one at 0. */
			if (timer == 0)
				audio.pitch = 0.5F;
			audio.Play();
		}
		if (timer == 0) {
			/* Disable all movement, enable camera blur, flag "Time Up!" screen, stop the timer, and show the cursor. */
			if (boatAudio.isPlaying)
				boatAudio.Stop();
			playerController.canControl = false;
			playerMouseLook.enabled = false;
			cameraMouseLook.enabled = false;
			cameraBlur.enabled = true;
			isTimeUp = true;
			//Time.timeScale = 0.0F;
			CancelInvoke("DecTimer");
			Screen.showCursor = true;
		}
	}
	
	public void IncScore() {
		/* On increment, if the score is a new record, save the new value in GameData. */
		if(++score > GameData.highScore)
			GameData.highScore = score;
	}
}