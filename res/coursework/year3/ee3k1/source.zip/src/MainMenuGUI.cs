using UnityEngine;
using System.Collections;

public class MainMenuGUI : MonoBehaviour {
	
	public enum GUIScreen { Main, CreatureLog };
	public GUIScreen currentScreen = GUIScreen.Main;
	
	public Texture2D logo;
	public Texture2D birdTex, turtleTex, dolphinTex, fishTex;
	
	void OnGUI() {
		/* Draw GUI to fit all resolutions; code is self-explanatory. */
		if (currentScreen == GUIScreen.Main) {
			int width = Screen.width-40, height = width/4;
			GUI.DrawTexture(new Rect(20, (Screen.height/3)-(height/2), width, height), logo);
			if (GUI.Button(new Rect((Screen.width-100)/2, (Screen.height/2)+20, 100, 30), "Time Trial")) {
				GameData.timeTrial = true;
				Application.LoadLevel(1);
			}
			if (GUI.Button(new Rect((Screen.width-100)/2, (Screen.height/2)+60, 100, 30), "Explore")) {
				GameData.timeTrial = false;
				Application.LoadLevel(1);
			}
			if (GUI.Button(new Rect((Screen.width-100)/2, (Screen.height/2)+100, 100, 30), "Creature Log")) {
				currentScreen = GUIScreen.CreatureLog;
			}
			if (GUI.Button(new Rect((Screen.width-100)/2, (Screen.height/2)+140, 100, 30), "Quit")) {
				Application.Quit();
			}
			GUI.Box(new Rect((Screen.width-250)/2, Screen.height-30, 250, 24), "Your personal best: "+GameData.highScore+" saved creature"+(GameData.highScore!=1?"s":""));
		} else if (currentScreen == GUIScreen.CreatureLog) {
			int creatureSize = 100;
			
			GUI.Label(new Rect(0, 0, Screen.width, Screen.height), new GUIContent("",
				"A myriad of creatures are affected by oil spills both directly and indirectly in the wake of food chain and habitat disturbances.\n\n" +
				"Move your mouse over the creatures you've seen to learn more about them."));
			
			GUI.Label(new Rect(Screen.width*0.2F - creatureSize/2, (Screen.height/4)-(creatureSize/2), creatureSize, creatureSize), new GUIContent(birdTex,
				"Birds are the animals most people think about when it comes to oil spills. The oil sticks to the poor creatures' feathers " +
				"making them unable to fly and often causing hypothermia. Cleaning them is extremely difficult and time consuming and they end up getting sick by eating " +
				"contaminated food.\n\nMostly affected are pelicans due to their habitat and migratory song birds that flock " +
				"to affected areas by the millions."));
			
			GUI.Label(new Rect(Screen.width*0.4F - creatureSize/2, (Screen.height/4)-(creatureSize/2), creatureSize, creatureSize), new GUIContent(turtleTex,
				"Sea Turtles probably have it the hardest; everything the have is affected. Their breeding grounds get contaminated " +
				"and their babies and eggs get damaged. In addition to this, their feeding areas take a severe hit.\n\n" +
				"In order to be saved, the turtles need to be cleaned and their blood monitored. Their eggs also need to be moved " +
				"to clean waters before they hatch. The controlled burning of oil slicks done by BP to reduce the amount of oil " +
				"in the gulf also cost many sea turtles of endangered species their lives."));
			
			GUI.Label(new Rect(Screen.width*0.6F - creatureSize/2, (Screen.height/4)-(creatureSize/2), creatureSize, creatureSize), new GUIContent(dolphinTex,
				"Among other marine mammals, such as whales, dolphins are also in danger. Fortunately the oil does not adhere to their " +
				"skin well, however it enters their bodies through the food they eat. Furthermore they need to surface for air " +
				"and breathe in toxins released by the oil slick on the surface of the water."));
			
			GUI.Label(new Rect(Screen.width*0.8F - creatureSize/2, (Screen.height/4)-(creatureSize/2), creatureSize, creatureSize), new GUIContent(fishTex,
				"Fish, including sharks, have their spawning and nursing areas compromised and their airways severly damaged. " +
				"Some species, such as the Atlantic bluefin tuna are well on their way to extinction and due to being low down on " +
				"the food chain, their predators can either starve or ingest contaminated food. Lines of dead jellyfish could be seen " +
				"on the gulf coast with oil still visible in their translucent bells.\n\nUnfortunately it's unrealistic to save them which " +
				"is why they lay dead on the shore in the simulation."));
			
			GUI.Box(new Rect(20, Screen.height/2, Screen.width-40, Screen.height/2 - 50), "Creature Info");
			GUI.Label(new Rect(40, Screen.height/2 + 25, Screen.width-80, Screen.height/2 - 75), GUI.tooltip);			
			if (GUI.Button(new Rect((Screen.width-100)/2, Screen.height-40, 100, 30), "Back")) {
				currentScreen = GUIScreen.Main;
			}
		}
	}
}