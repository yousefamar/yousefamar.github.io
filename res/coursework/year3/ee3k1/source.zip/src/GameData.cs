using UnityEngine;
using System.Collections;

/** A class with static, globally accessible fields to store data across scenes. */
public class GameData : MonoBehaviour {
	
	public static bool timeTrial = true;
	public static int highScore = 0;
	
}